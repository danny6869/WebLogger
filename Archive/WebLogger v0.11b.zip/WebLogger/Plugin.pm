package Plugins::WebLogger::Plugin;

# Plugin for Slimdevices SlimServer software that updates a file/script on the
# web with information about the currently playing song everytime a new song
# is listened to.
#
# Copyright (C) 2004 Danny Rego (danny@rego.com)
#
# This code is derived from code with the following copyright message:
#
# SliMP3 Server Copyright (C) 2001 Sean Adams, Slim Devices Inc.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use Slim::Control::Command;
use Slim::Utils::Strings qw (string);
use Slim::Utils::Timers;
use Slim::Hardware::VFD;
use File::Spec::Functions qw(:ALL);
use FindBin qw($Bin);
use Slim::Music::Info;
use Slim::Buttons::Common;
use Slim::Web::HTTP;
use LWP::UserAgent;
use HTTP::Request::Common qw(POST GET);
use URI::Escape;
use File::Temp;
use Net::FTP;
use Time::HiRes;

use strict;

use vars qw($VERSION);
$VERSION = '0.11b';

# Points slimserver to the display name for this plugin...
sub getDisplayName() {return string('PLUGIN_WEBLOGGER_TITLE');}

# Turns on debugging text output...
my $_DEBUG=0;

# Contains all strings for this plugin, in all languages...
# (by using the string() function, translation is taken care of for us)
sub strings() { return '
PLUGIN_WEBLOGGER_TITLE
	EN	Web Logger
PLUGIN_WEBLOGGER_ERROR_TITLE
	EN	Web Logger Error
PLUGIN_WEBLOGGER_STATUS
	EN	Status
PLUGIN_WEBLOGGER_CONFIG
	EN	Configuration
PLUGIN_WEBLOGGER_CONFIG_LOG_TITLE
	EN	Log Song Title?
PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUM
	EN	Log Album Name?
PLUGIN_WEBLOGGER_CONFIG_LOG_ARTIST
	EN	Log Artist/Band Name?
PLUGIN_WEBLOGGER_CONFIG_LOG_TIMESTAMP
	EN	Log Timestamp?
PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUMART
	EN	Log Album Art?
PLUGIN_WEBLOGGER_CONFIG_LOG_YES
	EN	Log
PLUGIN_WEBLOGGER_CONFIG_LOG_NO
	EN	Do not log
PLUGIN_WEBLOGGER_ABOUT
	EN	About Web Logger
PLUGIN_WEBLOGGER_ABOUT_INFO
	EN	Written By: Danny Rego (danny@rego.com - http://www.regoroad.com)
PLUGIN_WEBLOGGER_ENABLED
	EN	Enabled
PLUGIN_WEBLOGGER_DISABLED
	EN	Disabled
PLUGIN_WEBLOGGER_CONFIG_URL
	EN	URL to Write To
PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD
	EN	HTTP Method of Submission
PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_GET
	EN	Submit using "get"
PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_POST
	EN	Submit using "post"
PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_MULTIPARTPOST
	EN	Submit using "multipart post"
PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK
	EN	HTTP Check for "OK" in response
PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK_ENABLED
	EN	Yes
PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK_DISABLED
	EN	No
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_TYPE
	EN	Album Art Style
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_THUMBNAIL
	EN	Yes (thumbail)
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ARTWORK
	EN	Yes (artwork)
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME
	EN	Album Art Filename
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME_PREFIX
	EN	Album Art Prefix
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT
	EN	Timeout
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT
	EN	Timeout
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_1
	EN	1 Second
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_2
	EN	2 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_5
	EN	5 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_10
	EN	10 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_15
	EN	15 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_30
	EN	30 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_60
	EN	60 Seconds
PLUGIN_WEBLOGGER_CONFIG_OUTPUT_TEMPLATE
	EN	Output Template
PLUGIN_WEBLOGGER_CONFIG_OUTPUT_FILENAME
	EN	Information Filename
PLUGIN_WEBLOGGER_CONFIG_FTP_DUMMYFILE
	EN	Filename for Dummy File
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE
	EN	Keep FTP connection open?
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_DISABLED
	EN	No
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_JUSTOPEN
	EN	Keep Connection Open
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_UPLOADDUMMY
	EN	Upload Dummy File
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_DOWNLOADDUMMY
	EN	Download Dummy File
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_DOWNLOADSONGINFO
	EN	Download Song Info
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_COMMANDS
	EN	Send Random Idle Commands
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_ANY
	EN	Random Everytime
PLUGIN_WEBLOGGER_CONFIG_FTP_PASSIVE
	EN	Use "passive" mode?
PLUGIN_WEBLOGGER_CONFIG_FTP_PASSIVE_ENABLED
	EN	Yes
PLUGIN_WEBLOGGER_CONFIG_FTP_PASSIVE_DISABLED
	EN	No
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ALWAYS
	EN	Always Upload Album Art
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ALWAYS_YES
	EN	Yes (upload placeholder when none available)
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ALWAYS_NO
	EN	No
'};

# Hash to keep settings of multiple squeezeboxes seperate...
my %active_client_list;
my $plugin_handle='weblogger';

# These are our defaults for any uninitialized vars (used all over the place)...
my %defaultConfigs=(
	status				=> 0,
	config_log_title		=> 'YES',
	config_log_album		=> 'YES',
	config_log_artist		=> 'YES',
	config_log_timestamp		=> 'YES',
	config_log_albumart		=> 'YES',
	config_url			=> 'file://c:\\',
	config_http_method		=> 'POST',
	config_http_checkforok		=> 1,
	config_output_template		=> 'Text.template.txt',
	config_output_filename		=> 'songinfo.txt',
	config_albumart_type		=> 'THUMB',
	config_albumart_filename	=> 'albumart.jpg',
	config_albumart_filename_prefix	=> '',
	config_albumart_always		=> 1,
	config_ftp_keepalive		=> 'JUSTOPEN',
	config_ftp_dummyfile		=> '000DUMMY.DAT',
	config_ftp_passive		=> 0,
	config_timeout			=> 5
);

# Definition of our config menu structure, and input items...
my %menuParams = (
	'PLUGIN_WEBLOGGER_TITLE' => {
		'listRef' =>
			[
				'PLUGIN_WEBLOGGER_STATUS'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_TITLE'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUM'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_ARTIST'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_TIMESTAMP'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUMART'
#				,'PLUGIN_WEBLOGGER_CONFIG_URL'
#				,'PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD'
#				,'PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK'
#				,'PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE'
#				,'PLUGIN_WEBLOGGER_CONFIG_FTP_DUMMYFILE'
#				,'PLUGIN_WEBLOGGER_CONFIG_FTP_PASSIVE'
#				,'PLUGIN_WEBLOGGER_CONFIG_OUTPUT_TEMPLATE'
#				,'PLUGIN_WEBLOGGER_CONFIG_OUTPUT_FILENAME'
#				,'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_TYPE'
#				,'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME'
#				,'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME_PREFIX'
#				,'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ALWAYS'
				,'PLUGIN_WEBLOGGER_CONFIG_TIMEOUT'
				,'PLUGIN_WEBLOGGER_ABOUT'
			]
		,'stringExternRef' => 1
		,'header' => 'PLUGIN_WEBLOGGER_TITLE'
		,'stringHeader' => 1
		,'headerAddCount' => 1
		,'callback' => \&menuTransitionHandler
		,'overlayRef' => sub {return (undef,Slim::Hardware::VFD::symbol('rightarrow'));}
		,'overlayRefArgs' => ''
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_STATUS') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0,1]
		,'externRef' => ['PLUGIN_WEBLOGGER_DISABLED','PLUGIN_WEBLOGGER_ENABLED']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_TITLE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'status'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'status'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_URL') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_URL'
		,'initialValue' => sub { _getParam($_[0],'config_url'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_url'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['GET','POST','MULTIPARTPOST']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_GET','PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_POST','PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_MULTIPARTPOST']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_http_method'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_http_method'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0,1]
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK_DISABLED','PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK_ENABLED']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_http_checkforok'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_config_http_checkforok'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_ALBUMART_TYPE') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['THUMB','COVER']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_ALBUMART_THUMBNAIL','PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ARTWORK']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_TYPE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_albumart_type'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_albumart_type'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME'
		,'initialValue' => sub { _getParam($_[0],'config_albumart_filename'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_albumart_filename'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME_PREFIX') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME_PREFIX'
		,'initialValue' => sub { _getParam($_[0],'config_albumart_filename_prefix'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_albumart_filename_prefix'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [1,2,5,10,15,30,60]
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_1','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_2','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_5','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_10','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_15','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_30','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_60']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_TIMEOUT'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_timeout'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_timeout'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_OUTPUT_TEMPLATE') => {
		'useMode' => 'INPUT.List'
		,'listRef' => []
		,'externRef' => []
		,'stringExternRef' => 0
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_OUTPUT_TEMPLATE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_output_template') }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_output_template'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_OUTPUT_FILENAME') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_TITLE'
		,'initialValue' => sub { _getParam($_[0],'config_output_filename'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_output_filename'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_LOG_TITLE') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_TITLE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_title'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_title'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUM') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUM'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_album'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_album'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_LOG_ARTIST') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_ARTIST'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_artist'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_artist'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_LOG_TIMESTAMP') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_TIMESTAMP'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_timestamp'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_timestamp'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUMART') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUMART'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_albumart'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_albumart'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ALWAYS') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0,1]
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ALWAYS_NO','PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ALWAYS_YES']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ALWAYS'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_albumart_always'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_albumart_always'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['DISABLED','JUSTOPEN','UPLOADDUMMY','DOWNLOADDUMMY','DOWNLOADSONGINFO','COMMANDS','ANY']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_DISABLED','PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_JUSTOPEN','PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_UPLOADDUMMY','PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_DOWNLOADDUMMY','PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_DOWNLOADSONGINFO','PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_COMMANDS','PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_ANY']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_ftp_keepalive'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_ftp_keepalive'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_FTP_DUMMYFILE') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_TITLE'
		,'initialValue' => sub { _getParam($_[0],'config_ftp_dummyfile'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_ftp_dummyfile'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_FTP_PASSIVE') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0,1]
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_FTP_PASSIVE_DISABLED','PLUGIN_WEBLOGGER_CONFIG_FTP_PASSIVE_ENABLED']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_FTP_PASSIVE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_ftp_passive'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_ftp_passive'); }
	}
	,catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_ABOUT') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0]
		,'externRef' => ['PLUGIN_WEBLOGGER_ABOUT_INFO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_ABOUT'
		,'stringHeader' => 1
	}
);

sub setMode {
	my $client = shift;
	my $method = shift;

	# This is called whenever this plugin's config menu is entered from the main plugins menu...

	if ($method eq 'pop') {
		# We get here when we exit back out to the main plugins menu...
		# (by hitting the "left" button)
		Slim::Buttons::Common::popModeRight($client);
		return;
	}

	# Tell our menu hash to start at the main menu, and tell it which client we're configuring...
	my %params = %{$menuParams{'PLUGIN_WEBLOGGER_TITLE'}};
	$params{'valueRef'} = \$active_client_list{$client}{activemenu};
	Slim::Buttons::Common::pushMode($client,'INPUT.List',\%params);
	$client->update();
}

sub menuTransitionHandler {
	my ($client,$exittype) = @_;

	# Called whenever the menu/item changes so that it can handle the transition effect...
	# (and, as it happens...setup default values that can't be set in the hash)
	# (some values CAN be set in the hash for some types, and not others, so we set them ALL up here so the hash can be defined consistantly for all types)

	$exittype = uc($exittype);
	if ($exittype eq 'LEFT') {
		# Called when exiting back to the main plugins menu...
		Slim::Buttons::Common::popModeRight($client);
	} elsif ($exittype eq 'RIGHT') {
		# Entering a sub-menu/sub-item...
		my $nextmenu = catdir('PLUGIN_WEBLOGGER_TITLE',$active_client_list{$client}{activemenu});
		if (exists($menuParams{$nextmenu})) {
			my %nextParams = %{$menuParams{$nextmenu}};
			if ($nextParams{'useMode'} eq 'INPUT.List') {
				# We are entering a list input specifically...

				if(exists($nextParams{'initialValue'})) {
					# Make sure it's preference value is set to what it currently is, or the default...
					my $value;
					if (ref($nextParams{'initialValue'}) eq 'CODE') {
						# Retrieve the value from the specified function...
						$value = $nextParams{'initialValue'}->($client);
					} else {
						# Reload it's initial value (usually from prefs file...specifid in embedded sub)...
						$value = _getParam($client,$nextParams{'initialValue'},1);
					}
					$nextParams{'valueRef'} = \$value;
				}

				if(exists($nextParams{'headerString'})) {
					# Set the header by our strings table...
					$nextParams{'header'}=string($nextParams{'headerString'});
				}

			} elsif ($nextParams{'useMode'} eq 'INPUT.Text') {
				# We are entering a text input specifically...

				if(exists($nextParams{'initialValue'})) {
					# Make sure it's preference value is set to what it currently is, or the default...
					my $value;
					if (ref($nextParams{'initialValue'}) eq 'CODE') {
						# Retrieve the value from the specified function...
						$value = $nextParams{'initialValue'}->($client);
					} else {
						# Reload it's initial value (usually from prefs file...specifid in embedded sub)...
						$value = _getParam($client,$nextParams{'initialValue'},1);
					}
					$nextParams{'valueRef'} = \$value;
				}

				if(exists($nextParams{'headerString'})) {
					# Set the header by our strings table...
					$nextParams{'header'}=string($nextParams{'headerString'});
				}

			}
			Slim::Buttons::Common::pushModeLeft(
				$client
				,$nextParams{'useMode'}
				,\%nextParams
			);
		} else {
			# We are trying to enter a menu that doesn't exist...
			# (just bump, and redisplay same menu, so some activity is shown at least)
			Slim::Display::Animation::bumpRight($client);
		}
	} else {
		# ...should never make it here...
		return;
	}
}

sub _getParam
{
	my($client,$prefName,$isFullName)=@_;

	# Reads a preference for this plugin from the main pref file, and if it's not set yet, returns the specified default...

	my $returnValue;
	if($isFullName) {
		# The name passed in isn't necessarily a plugin var...it could be anything, so don't prefix the plugin handle...
		$returnValue=Slim::Utils::Prefs::clientGet($client,$prefName);
	} else {
		# Get the value of the preference...it's stored as part of the plugin's prefs...
		$returnValue=Slim::Utils::Prefs::clientGet($client,$plugin_handle.'_'.$prefName);
	}

	# If no setting was retrieved, use the specified default...
	if(!defined($returnValue)) {
		$returnValue=$defaultConfigs{$prefName};
	}

	return($returnValue);
}

sub _setParam
{
	my($client,$prefName,$value,$isFullName)=@_;

	# Writes a preference for this plugin to the main preference file...

	if($isFullName) {
		# The name passed in isn't necessarily a plugin var...it could be anything, so don't prefix the plugin handle...
		Slim::Utils::Prefs::clientSet($client,$prefName,withoutEscapes($value));
		return(1);
	}

	# Set the value of the preference...it's stored as part of the plugin's prefs...
	Slim::Utils::Prefs::clientSet($client,$plugin_handle.'_'.$prefName,withoutEscapes($value));
	return(1);
}

sub inputCallback {
	my ($client,$type,$param_key) = @_;

	# Called when the input item is trying to exit...it's up to us to decide what to do at that point...

	my $nextmenu = catdir('PLUGIN_WEBLOGGER_TITLE',$active_client_list{$client}{activemenu});
	if (exists($menuParams{$nextmenu})) {
		my %nextParams = %{$menuParams{$nextmenu}};

		# Get the entered value (without the trailing control characters that show the arrows etc...
		my $valueRef=${Slim::Buttons::Common::param($client,'valueRef')};
		$valueRef=~s/vfD\_.+\_Vfd//gs;

		if ($nextParams{'useMode'} eq 'INPUT.List') {
			# left OR right - It doesn't matter, just store it
			if(($type eq 'left')||($type eq 'right')) {
				# It doesn't matter how they leave, store what they left it at...
				_setParam($client,$param_key,$valueRef,0);
			}
		} elsif($nextParams{'useMode'} eq 'INPUT.Text') {
			if($type eq 'backspace') {
				# They are cancelling out of the text input...
				# (leave it alone)
			} elsif($type eq 'nextChar') {
				# In essence, they've hit enter...
				_setParam($client,$param_key,$valueRef,0);
			}
		}
	}

	Slim::Buttons::Common::popModeRight($client);
}

###############################################################################
#
# Everything ABOVE this line defines the config menu for this plugin...
#
# Everything BELOW this line is what makes the plugin work...
#
###############################################################################

sub _errorOut
{
	my($errormessage)=@_;
	$@=$errormessage;
	return(0);
}

sub parseSubmissionURL
{
	my($url)=@_;
	my %paramlist;

	# Breaks a URL down into the actual URL, and any params that might be in there...
	# (returns them seperated as a STRING, and HASHREF)

	if($url=~/(.*)\?([^?]+)/) {
		my $params;
		($url,$params)=($1,$2);
		foreach my $paramstring (split(/[?&]+/,$params)) {
			if($paramstring=~/^([^=]*)=([^=]*)$/) {
				$paramlist{$1}=uri_unescape($2);
			}
		}
	}
	return($url,\%paramlist);
}

sub withoutEscapes
{
	my($line)=@_;
# XXX - There has to be a better/more proper way to do this...
	# Old-style escapes...
	$line=~s/\_\_[^\_]+\_\_//gmi;
	# New-style escapes...
	$line=~s/\x1e[^\x1e]+\x1e//gmi;
	# Get rid of special chars (like the right arrow) that might be there from the input...
	$line=~s/\x1f[^\x1f]+\x1f//gmi;
	return($line);
}

sub _getTimestamp
{
	my($client)=@_;
	my @datelines=Slim::Buttons::Common::dateTime($client);
	my $timestamp="$datelines[0] $datelines[1]";
	return(withoutEscapes($timestamp));
}

sub _storeSongInfo
{
	my($client,$songinfo)=@_;

	# Stores the song information (minus the timestamp) we've just updated
	# with so that we can check to see if it's changed on the next update
	# attempt...('cause if it's the same, we shouldn't bother then)

	$active_client_list{$client}{lastsonginfo}={};
	foreach my $key (keys(%$songinfo)) {
		next if($key eq 'TIMESTAMP');
		$active_client_list{$client}{lastsonginfo}{$key}=$songinfo->{$key};
	}
}

sub _songInfoChanged
{
	my($client,$songinfo)=@_;

	# Checks to see if the song information we're going to update to is different from what was written on the last update...
	# (ignoring the TIMESTAMP field as that changes every second)

	$active_client_list{$client}{lastsonginfo}={} if(!exists($active_client_list{$client}{lastsonginfo}));
	foreach my $key (keys(%$songinfo)) {
		next if($key eq 'TIMESTAMP');
		if((!exists($active_client_list{$client}{lastsonginfo}{$key}))||($songinfo->{$key} ne $active_client_list{$client}{lastsonginfo}{$key})) {
			return(1);
		}
	}

	# Nothing's changed...it looks the same...
	return(0);
}

sub _getAllLogItems
{
	my($client)=@_;
	my @logitems;
	my @checklist=('title','album','artist','timestamp','albumart');

	foreach my $key (@checklist) {
		if(uc(_getParam($client,'config_log_'.$key)) ne 'NO') {
			push(@logitems,uc($key));
		}
	}

	return(@logitems);
}

sub getSongAsFile
{
	my($client,$songinfo)=@_;
	my $containsfiles=0;

	# Gets our template all ready for transmission...

	my $template_filename=_getParam($client,'config_output_template');

	# If this file type can package up, and include the raw graphic data, we need to know...
	# (so we don't send the graphic twice)
	if($template_filename=~/\.xml$/) {
		$containsfiles=1;
	}

	# Get our "file" contents ready for output...
	my $templateref=Slim::Web::HTTP::filltemplatefile('Plugins/WebLogger/html/templates/'.$template_filename,{SONG => $songinfo});
	my $output=$$templateref;

	return($output,$containsfiles);
}

sub getSongData
{
	my($client,$tempfileurl,$forlocaldisplayonly)=@_;
	my @logitems=_getAllLogItems($client);
	my %newinfo;

	# Load all of the information about this song that we've got, and might be using...

	# Make a new hash that we can manipulate without screwing up database data...
	# ('cause we need to add the timestamp, and who knows what else in the future)

	# Get the tag information that we want for the specified file, and store it in our hash...
	my $songinfo=Slim::Music::Info::readTags($tempfileurl);
	foreach my $item (@logitems) {
		if($item eq 'TIMESTAMP') {
			$newinfo{$item}=_getTimestamp($client);
		} elsif($item eq 'ALBUMART') {
			# They've specified that they want the album art uploaded...
			# Add the graphic they've requested...
			my $albumarttype=uc(_getParam($client,'config_albumart_type'));

			# Load the selected album art...
			my($imageData,$contentType,$mtime)=Slim::Music::Info::coverArt(Slim::Utils::Misc::fixPath($tempfileurl),lc($albumarttype));
			if(defined($imageData)) {
				$newinfo{ALBUMART}=$imageData;

				# Set the URL in the hash so we know how to access it from HTML...
				if($forlocaldisplayonly) {
					$newinfo{ALBUMARTURL}="/music/".$tempfileurl."/".lc($albumarttype).".jpg";
					$newinfo{ALBUMARTURL}=~s/file:\/\///;
				} else {
					$newinfo{ALBUMARTURL}=_getParam($client,'config_albumart_filename_prefix')._getParam($client,'config_albumart_filename');
				}
			}

			# If no album art was retrieved (for whatever reason), then load the default...
			if((!$newinfo{ALBUMART})&&(_getParam($client,'config_albumart_always'))) {
				# Load the default album art...
				print STDERR "Loading default album art graphic file.\n" if($_DEBUG);

				# ...using default html template handlers...
				if($newinfo{ALBUMART}=${Slim::Web::HTTP::getStaticContent('Plugins/WebLogger/html/images/_'.lc($albumarttype).'.jpg')}) {
					# Set the URL in the hash so we know how to access it from HTML...
					if($forlocaldisplayonly) {
						$newinfo{ALBUMARTURL}='/Plugins/WebLogger/html/images/_'.lc($albumarttype).'.jpg';
					} else {
						$newinfo{ALBUMARTURL}=_getParam($client,'config_albumart_filename_prefix')._getParam($client,'config_albumart_filename');
					}
					print STDERR "Default album art graphic file successfully loaded.\n" if($_DEBUG);
				} else {
					print STDERR "Default album art graphic file could not be loaded.\n" if($_DEBUG);
				}
			}
		} else {
			$newinfo{$item}=$songinfo->{$item};
		}
	}

	return(\%newinfo);
}

sub _setFTPKeepAliveTimer
{
	my($client,$server,$username,$password,$filepath)=@_;
	my $_MINIMUM=15;
	my $_MAXIMUM=60;
	my $timerval=$_MINIMUM+rand($_MAXIMUM-$_MINIMUM);

	# Just sets the keep alive timer to a semi-random value so we can
	# keep the ftp connection open...

	Slim::Utils::Timers::setTimer($client, (Time::HiRes::time() + $timerval), \&_keepFTPAlive, $server, $username, $password, $filepath);
}

sub _keepFTPAlive
{
	my($client,$server,$username,$password,$filepath)=@_;

	# Send a command to the FTP server so it doesn't think we've fallen asleep...
	# The _loginFTP function does this for us, so let's just use that...
	# PLUS...if we're not logged in (for whatever reason), it will make sure we do...

	# Get our keep alive settings (including dummy file filename)...
	my $keepalive=uc(_getParam($client,'config_ftp_keepalive'));
	my $dummyfile=_getParam($client,'config_ftp_dummyfile');

	# Not fussy...
	if($keepalive eq 'ANY') {
		# Pick a random one out of the list...
		my @random_keepalive_types=qw(UPLOADDUMMY UPLOADDUMMY DOWNLOADSONGINFO COMMANDS);
		$keepalive=$random_keepalive_types[rand(scalar(@random_keepalive_types))];
	}

	# Just incase we got here by some wierd mistake?!
	if($keepalive eq 'DISABLED') {
		return;
	}

	eval {
		local $SIG{ALRM}=sub{die "Keep alive time of 2 seconds exceeded"};
		alarm(2);
		if((exists($active_client_list{$client}{openftp}))&&(defined($active_client_list{$client}{openftp}))) {
			# Alright...we have an FTP object, and should be logged in...
			if($keepalive eq 'COMMANDS') {
				my @random_keepalive_commands=('pwd','rest 0','type i','type a','noop','dir','ls');	# ,'list','stat'
				my $command_to_send=$random_keepalive_commands[rand(scalar(@random_keepalive_commands))];
				$active_client_list{$client}{openftp}->quot($command_to_send);
			} elsif($keepalive eq 'UPLOADDUMMY') {
				my $tempfile; # Asking for undef doesn't actually open the file...it just gives us a temp filename to use. 
				(undef,$tempfile)=File::Temp::tempfile();

				# Write to our temporary file...
				if(open(TEMPFILEFH,"> $tempfile")) {
					print TEMPFILEFH $dummyfile;
					close(TEMPFILEFH);
				}

				# Now send the dummy file to the FTP site, but name it properly...
				if(!$active_client_list{$client}{openftp}->put($tempfile,$dummyfile)) {
					die($active_client_list{$client}{openftp}->message());
				}

				# We're done with our temporary file...
				unlink($tempfile);
			} elsif($keepalive eq 'DOWNLOADDUMMY') {
				my $tempfile; # Asking for undef doesn't actually open the file...it just gives us a temp filename to use. 
				(undef,$tempfile)=File::Temp::tempfile();

				# Now get the dummy file from the FTP site...
				if(!$active_client_list{$client}{openftp}->get($dummyfile,$tempfile)) {
					die($active_client_list{$client}{openftp}->message());
				}

				# We're done with our temporary file...
				unlink($tempfile);
			} elsif($keepalive eq 'DOWNLOADSONGINFO') {
				my $tempfile; # Asking for undef doesn't actually open the file...it just gives us a temp filename to use. 
				(undef,$tempfile)=File::Temp::tempfile();

				# Now get the song information file from the FTP site...
				if(!$active_client_list{$client}{openftp}->get(_getParam($client,'config_output_filename'),$tempfile)) {
					die($active_client_list{$client}{openftp}->message());
				}

				# We're done with our temporary file...
				unlink($tempfile);
			}
		}
		alarm(0);
	};

	if($@) {
		# We need to clear this out so slim server's internal timer stuff doesn't choke...
		alarm(0);
		print STDERR string('PLUGIN_WEBLOGGER_ERROR_TITLE')." _keepAlive(): $@\n" if($_DEBUG);
	}

	# Gotta come back and do this again in a bit...
	_setFTPKeepAliveTimer($client, $server, $username, $password, $filepath);
}

sub _loginFTP
{
	my($client,$server,$username,$password,$filepath)=@_;

	# Opens our FTP session, and navigates us to the directory where we need to send the files...
	# (caches the connection if the keepalive flag is set for fast updates)

# XXX - Whenever our config has changed we should login again (logout at least)...

	if((exists($active_client_list{$client}{openftp}))&&(defined($active_client_list{$client}{openftp}))) {
		# FTP should still be alive!?  (what if we were kicked out?!)
		# Test to see if we're still logged in by issuing a useless command...
		if($active_client_list{$client}{openftp}->cwd($filepath)) {
			# Return our working FTP handle..
			return($active_client_list{$client}{openftp});
		} # else we were disconnected...so continue on, so we can login again...
	}

	# If we've made it here...we need to create an FTP session, and login with the provided info...
	$active_client_list{$client}{openftp}=new Net::FTP($server,
		Passive => _getParam($client,'config_ftp_passive'),
		Debug => $_DEBUG);
	if(!$active_client_list{$client}{openftp}) {
		die("Bad server: $server");
	}

	# Login without our specified info...
	if(!$active_client_list{$client}{openftp}->login($username,$password)) {
		die($active_client_list{$client}{openftp}->message());
	}

	# Go to the specified sub-directory...
	if(($filepath)&&(!$active_client_list{$client}{openftp}->cwd($filepath))) {
		die($active_client_list{$client}{openftp}->message());
	}

	# Successful...return the object for use...
	return($active_client_list{$client}{openftp});
}

sub _logoutFTP
{
	my($client)=@_;

	# Logs out, and kills our FTP session unless the keepalive flag is set...

	if((!exists($active_client_list{$client}{openftp}))||(!defined($active_client_list{$client}{openftp}))) {
		# No ftp connection, so don't bother logging out...
		return;
	}

	if(_getParam($client,'config_ftp_keepalive') ne 'DISABLED') {
		# They want to keep the FTP connection alive...so don't quit...
		# (leave it open, and ready for the next call)
		return;
	}

	# We're done with FTP...log out nicely...
	if(!$active_client_list{$client}{openftp}->quit()) {
		die($active_client_list{$client}{openftp}->message());
	}

	# We don't undef the reference to the FTP object, because it helps GREATLY for
	# speed if we don't have to re-init a new FTP object everytime...
	# (I'm not sure why because we're doing a "new" everytime...but oh well...)
	# $active_client_list{$client}{openftp}=undef;

	return;
}

sub _updateByFTP
{
	my($client,$songinfo,$url,$timeout)=@_;

	# Rips the specified URL apart into the bits we need...
	my ($username,$password,$server,$filepath)=();
	if($url=~/^ftp:\/\/(.*):(.*)@([^\\\/]*)([\\\/].*)?[\\\/]?$/i) {
		$username=uri_unescape($1 || '');
		$password=uri_unescape($2 || '');
		$server=uri_unescape($3 || '');
		$filepath=uri_unescape($4 || '');
	} else {
		return(_errorOut("Bad URL: $url"));
	}

	# Kill off current timer (if any)...
	Slim::Utils::Timers::killTimers($client,\&_keepFTPAlive);

	# Let's do the actual FTP now that we have our info...
	my $ftp;
	eval
	{
		# Set the timer...
		local $SIG{ALRM}=sub{die "$timeout second limit reached"};
		alarm($timeout);

		# Get our FTP object to where we need to be logged in...
		my $ftp=_loginFTP($client,$server,$username,$password,$filepath);

		# Let's just send everything as a binary type...the worst that can happen is
		# extra/missing CR/LF characters depending what type of machine we're transferring between...
		if(!$ftp->binary()) {
			die($ftp->message());
		}

		# Make a list of files to upload (we already have them in memory, so we have to fudge some stuff)
		my %files;
		my($songfile,$containsfiles)=getSongAsFile($client,$songinfo);
		$files{_getParam($client,'config_output_filename')}=$songfile;
		$files{_getParam($client,'config_albumart_filename')}=$songinfo->{ALBUMART} if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))&&(!$containsfiles));

		foreach my $filename (keys(%files)) {
			my $tempfile; # Asking for undef doesn't actually open the file...it just gives us a temp filename to use. 
			(undef,$tempfile)=File::Temp::tempfile();

			# Write to our temporary file...
			if(open(TEMPFILEFH,"> $tempfile")) {
				binmode TEMPFILEFH;
				print TEMPFILEFH $files{$filename};
				close(TEMPFILEFH);
			}

			# Now send the temporary file to the FTP site, but name it properly...
			if(!$ftp->put($tempfile,$filename)) {
				die($ftp->message());
			}

			# We're done with our temporary file...
			unlink($tempfile);
		}

		# We're done with FTP (for now)...
		_logoutFTP($client);

		# Kill the timer...
		alarm(0);
	};

	# We need to do this because we are setting the timer in-between...
	# (it screws up $@)
	my $ftpError=$@;

	# Error or not...
	if(_getParam($client,'config_ftp_keepalive') ne 'DISABLED') {
		# Make sure we keep the FTP connection alive...
		_setFTPKeepAliveTimer($client, $server, $username, $password, $filepath);
	}

	if($ftpError) {

		# We need to kill the timer just incase we died out, and skipped the reset...
		# Otherwise, the timer could still go off, and cause the server to die...
		alarm(0);
		return(_errorOut("$ftpError"));
	}

	return(1);
}

sub _updateByLocalFile
{
	my($client,$songinfo,$url,$timeout)=@_;

	# Get rid of the file:// if any...
	my($filepath)=();
	if($url=~/^file:\/\/(.*)[\\\/]?/) {
		$filepath=$1 || '';
	} else {
		return(_errorOut("Could not parse specified URL.  ($url)"));
	}

	# Make a list of files to upload (we already have them in memory, so we have to fudge some stuff)
	my %files;
	my($songfile,$containsfiles)=getSongAsFile($client,$songinfo);
	$files{_getParam($client,'config_output_filename')}=$songfile;
	$files{_getParam($client,'config_albumart_filename')}=$songinfo->{ALBUMART} if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))&&(!$containsfiles));

	foreach my $filename (keys(%files)) {
		# Write out file...
		if(open(FILEOUTPUTFH,"> $filepath/$filename")) {
			binmode FILEOUTPUTFH;
			print FILEOUTPUTFH $files{$filename};
			close(FILEOUTPUTFH);
		} else {
			return(_errorOut("Could not write to \"$filepath/$filename\"."));
		}
	}

	return(1);
}

sub _updateByHTTPMultipartPost
{
	my($client,$songinfo,$url,$paramlist,$timeout)=@_;

	# Make a list of files to upload (we already have them in memory, so we have to fudge some stuff)
	my %files;
	my($songfile,$containsfiles)=getSongAsFile($client,$songinfo);
	$files{_getParam($client,'config_output_filename')}=$songfile;
	$files{_getParam($client,'config_albumart_filename')}=$songinfo->{ALBUMART} if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))&&(!$containsfiles));

	# Prepare our HTTP request...
	my $request=POST $url, Content_Type => 'form-data', Content => [%$paramlist, %files];

	# Create our UserAgent, and send the file/params...
	# (submit our faked "form" data)
	my $ua = LWP::UserAgent->new;
	$ua->parse_head(0);	# Slimserver does not include the HTML::HeadeParser module(s)...
	$ua->timeout($timeout);
	my $response=$ua->simple_request($request);
	if($response->is_error()) {
		my $errorCode=$response->code;
		my $errorMessage=$response->message;
		$errorMessage='Connection timed out.' if(($errorCode==500)&&(!$errorMessage));
		return(_errorOut("$errorMessage (#$errorCode)"));
	}

	# Check for, and return an error, or continue on if successful...
	my $content=$response->content;
	if((_getParam($client,'config_http_checkforok'))&&($content!~/^OK/)) {
		return(_errorOut($content));
	}

	return(1);
}

sub _updateByHTTPPost
{
	my($client,$songinfo,$url,$paramlist,$timeout)=@_;

	# Add song information if it's not to be sent as a file type...
	# Add the one hash to the other...now we're ready to submit...
	foreach my $infokey (keys(%$songinfo)) {
		next if($infokey=~/^ALBUMART/);
		$paramlist->{$infokey}=$songinfo->{$infokey};
	}

	# Prepare our HTTP request...
	my $request=POST $url, [%$paramlist];

	# Create our UserAgent, and send the file/params...
	# (submit our faked "form" data)
	my $ua = LWP::UserAgent->new;
	$ua->parse_head(0);	# Slimserver does not include the HTML::HeadeParser module(s)...
	$ua->timeout($timeout);
	my $response=$ua->simple_request($request);
	if($response->is_error()) {
		my $errorCode=$response->code;
		my $errorMessage=$response->message;
		$errorMessage='Connection timed out.' if(($errorCode==500)&&(!$errorMessage));
		return(_errorOut("HTTP Error #$errorCode: $errorMessage"));
	}

	# Check for, and return an error, or continue on if successful...
	my $content=$response->content;
	if((_getParam($client,'config_http_checkforok'))&&($content!~/^OK/)) {
		return(_errorOut($content));
	}

	# If they want the graphic sent...return an error because there's no way to do it via GET...
	if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))) {
		return(_errorOut("Album art upload via standard POST not possible.  (Use \"multipart post\" instead)"));
	}

	return(1);
}

sub _updateByHTTPGet
{
	my($client,$songinfo,$url,$paramlist,$timeout)=@_;

	# Add song information if it's not to be sent as a file type...
	# Add the one hash to the other...now we're ready to submit...
	foreach my $infokey (keys(%$songinfo)) {
		next if($infokey=~/^ALBUMART/);
		$paramlist->{$infokey}=$songinfo->{$infokey};
	}

	# Rebuild URL with the params that have been added to etc...
	$url.='?';
	foreach my $key (keys(%$paramlist)) {
		$url.=$key."=".uri_escape($paramlist->{$key})."&";
	}

	# Prepare our HTTP request...
	my $request=GET $url;

	# Create our UserAgent, and send the file/params...
	# (submit our faked "form" data)
	my $ua = LWP::UserAgent->new;
	$ua->parse_head(0);	# Slimserver does not include the HTML::HeadeParser module(s)...
	$ua->timeout($timeout);
	my $response=$ua->simple_request($request);
	if($response->is_error()) {
		my $errorCode=$response->code;
		my $errorMessage=$response->message;
		$errorMessage='Connection timed out.' if(($errorCode==500)&&(!$errorMessage));
		return(_errorOut("$errorMessage (#$errorCode)"));
	}

	# Check for, and return an error, or continue on if successful...
	my $content=$response->content;
	if((_getParam($client,'config_http_checkforok'))&&($content!~/^OK/)) {
		return(_errorOut($content));
	}

	# If they want the graphic sent...return an error because there's no way to do it via GET...
	if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))) {
		return(_errorOut("Album art upload via GET not possible."));
	}

	return(1);
}

sub updateWeb
{
	my($client,$tempfileurl,$onlyifchanged)=@_;

	# Stores the song info on the specified server...

	# Don't do this unless it's enabled in the config...
	return(1) if(_getParam($client,'status')!=1);

	# Display text temporarily to let them know why it's paused (if it has at all)...
	Slim::Display::Animation::showBriefly($client,string('PLUGIN_WEBLOGGER_TITLE')." v$VERSION",'Updating song information...',1);

	# Get all of the song information that is selected for updating...
	my $songinfo=getSongData($client,$tempfileurl,0);

	# If nothing's changed since the last update...don't bother updating again...
	if(($onlyifchanged)&&(!_songInfoChanged($client,$songinfo))) {
		# Nothing's changed...skip the update...
		return(1);
	}

	# We need a timeout incase an update takes forever...
	# (we can't use ALARM because something else uses it within LWP, and it cancels our out)
	my $TIMEOUT=uc(_getParam($client,'config_timeout'));

	# Get our submission URL, and vars to pass in, and do it...
	my $url=_getParam($client,'config_url');
	if($url=~/^ftp:\/\//i) {
		# Send file to FTP site...
		if(!_updateByFTP($client,$songinfo,$url,$TIMEOUT)) {
			return(_errorOut($@));
		}
	} elsif($url=~/^https?:\/\//i) {
		# Submit as HTTP GET/POST to a script...

		# Rip out all specified params...
		my $paramlist;
		($url,$paramlist)=parseSubmissionURL($url);

		my $method=uc(_getParam($client,'config_http_method'));
		if($method eq 'MULTIPARTPOST') {
			# POST as file...
			if(!_updateByHTTPMultipartPost($client,$songinfo,$url,$paramlist,$TIMEOUT)) {
				return(_errorOut($@));
			}
		} elsif($method eq 'POST') {
			# POST just params...
			if(!_updateByHTTPPost($client,$songinfo,$url,$paramlist,$TIMEOUT)) {
				return(_errorOut($@));
			}
		} else {
			if(!_updateByHTTPGet($client,$songinfo,$url,$paramlist,$TIMEOUT)) {
				return(_errorOut($@));
			}
		}
	} else {
		# Text file output...
		if(!_updateByLocalFile($client,$songinfo,$url,$TIMEOUT)) {
			return(_errorOut($@));
		}
	}

	# The update is done...keep track of the songinfo to minimize un-necessary updates...
	_storeSongInfo($client,$songinfo);

	# All is well...we're done...
	return(1);	
}

sub commandCallback
{
	my($client,$paramsRef)=@_;

	if($paramsRef->[0] eq 'open') {

		# A new song is about to be played...
		# Get the currently playing song, and it's tag information, and write it where specified...

		if(!updateWeb($client,$paramsRef->[1],1)) {
			# There was an error, so display it...we can't use showBriefly() in the
			# normal way because we are between songs, and the display will be
			# over-written as soon as this is done, so we have to sleep to make sure
			# the message is displayed.
			my $displayTime=3;
			Slim::Display::Animation::showBriefly($client,string('PLUGIN_WEBLOGGER_ERROR_TITLE')." v$VERSION",$@,$displayTime);
			print STDERR string('PLUGIN_WEBLOGGER_ERROR_TITLE').": $@\n" if($_DEBUG);
			sleep($displayTime);
		}

		# $paramsRef->[1] will contain the file URL...
		# Example : file:///M:/Aerosmith/Greatest%20Hits/09%20Come%20Together.mp3
	}
}

sub getFunctions
{
	# Export the remote hook functions to the server...
	# (we don't need this crap)
	return({});
}

BEGIN
{
	# Register a callback function so that the server knows we want to hook in...
	Slim::Control::Command::setExecuteCallback(\&commandCallback);
}

END
{
	# Un-register our callback function...
	Slim::Control::Command::clearExecuteCallback(\&commandCallback);
}

###############################################################################
#
# Everything ABOVE this line in functionality
#
# Everything BELOW this line is the web configuration menu, and stuff...
#
###############################################################################

sub webPages
{
	my %pages=(
		"index\.(?:htm|xml)"		=> \&handleIndex
	);
	return(\%pages, "index.html");
}

sub _loadCustomTemplates
{
	my($client)=@_;
	my @templates;

	# Gets a list of all song information templates from the appropriate templates
	# directory...

	# I'm not exactly sure what order this should be in, or even if this is the right/best way to do it?!
	# I don't understand "skins" concept in slim server yet!!!
	my $skinpath = Slim::Web::HTTP::fixHttpPath(Slim::Utils::Prefs::get('skin'),'Plugins/WebLogger/html/templates')
		|| Slim::Web::HTTP::fixHttpPath(Slim::Web::HTTP::baseSkin(),'Plugins/WebLogger/html/templates');

	print STDERR "Reading template file list from \"$skinpath\" directory/folder.\n" if($_DEBUG);

	# Read the template file listing from the templates directory...
	if(opendir(DIRFH, $skinpath)) {
		# We just want "xxx.template.xxx" files...
		@templates=grep { /\.template/ } readdir(DIRFH);
		closedir(DIRFH);
	} else {
		# Couldn't open directory...
	}

	# Update the config menu items to have this info available...
	$menuParams{catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_OUTPUT_TEMPLATE')}{listRef}=[];
	$menuParams{catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_OUTPUT_TEMPLATE')}{externRef}=[];
	foreach my $template_filename (@templates) {
		if($template_filename=~/(.*)\.template.*/) {
			push(@{$menuParams{catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_OUTPUT_TEMPLATE')}{externRef}}
				,$1);
			push(@{$menuParams{catdir('PLUGIN_WEBLOGGER_TITLE','PLUGIN_WEBLOGGER_CONFIG_OUTPUT_TEMPLATE')}{listRef}}
				,$template_filename);
		}
	}

	# Return the filenames...
	return(@templates);
}

sub handleIndex
{
	my ($client, $params) = @_;
	my $template_to_show="Plugins/WebLogger/html/index.html";

	# Get the URL of the song at the top of the current playlist...
	# (the one playing, or the next one that will be played)
	my $currentlyplayingurl=undef;
	if((defined($client->[28]))&&(scalar(@{$client->[28]})>0)&&(defined($client->[29]))&&(scalar(@{$client->[29]})>0)) {
		# We should have a song URL...
		# Get the currently playing song by magical craziness...
		$currentlyplayingurl=$client->[28]->[$client->[29]->[$client->[30]]];
	}

	# What is it that we are supposed to do this time???
	if($params->{update_now}) {
		# We want to do a manual update...
		if($currentlyplayingurl) {
			# We should have a song URL...
			if(!updateWeb($client,$currentlyplayingurl,0)) {
				# There was an error, so display it...
				$params->{errorText}=$@;
			}
		} else {
			# There is no song currently playing...
			$params->{errorText}="Current playlist is empty.";
		}
	} elsif($params->{store_settings}) {
		# Run through configs, and save any changes...
		foreach my $key (keys(%defaultConfigs)) {
			# Set the submitted param in our preferences...
			if(!_setParam($client,$key,$params->{"$plugin_handle\_$key"},0)) {
				$params->{errorText}='Could not save value(s) in preference file.';
			}
		}
	} elsif($params->{preview_template}) {
		# This one simply handle the mini template viewing function...
		if($params->{template_name}) {
			$template_to_show='Plugins/WebLogger/html/show_template.html';
		}
	} else {
		# Just display the config page...we don't know what we want...
		# (we don't need to do anything for that yet)
	}

	# Load in ALL of our configuration settings, and add them for use in the config template(s)...
	foreach my $key (keys(%defaultConfigs)) {
		$params->{$plugin_handle.'_'.$key}=_getParam($client,$key);
	}

	# Get the listing of all the existing custom templates ready...
	_loadCustomTemplates($client);

	# Include our config menu, so we can access the same stuff...
	# (we still need the params above to make accessing nicer/easier)
	$params->{menuParams}={};
	foreach my $key (keys(%menuParams)) {
		my @keylist=split(/[\\\/]+/,$key);

		# All we want are the sub-items...not the root item...
		if(scalar(@keylist)>1) {
			foreach my $subkey (@keylist) {
				$params->{menuParams}{$subkey}=$menuParams{$key}
			}
		}

	}

	# We need some sample song data to display in examples and stuff...
	if($currentlyplayingurl) {
		# Add this song's information so it can be used for example display...
		my $songinfo=getSongData($client,$currentlyplayingurl,1);
		foreach my $key (keys(%$songinfo)) {
			$params->{SONG}{$key}=$songinfo->{$key};
		}

		# Oust the graphic data, or the display will be screwed!!!
		$params->{SONG}{ALBUMART}='*** GRAPHIC DATA ***';

	} else {
		# There is no song in the list...make up test data...
		$params->{SONG}{TITLE}='American Woman';
		$params->{SONG}{ARTIST}='The Guess Who';
		$params->{SONG}{ALBUM}='Greatest Hits';
		$params->{SONG}{TIMESTAMP}=_getTimestamp($client);
		$params->{SONG}{ALBUMART}='*** GRAPHIC DATA ***';
		$params->{SONG}{ALBUMARTURL}='/Plugins/WebLogger/html/images/_'.lc(_getParam($client,'config_albumart_type')).'.jpg';
	}

	# Add our plugin version number, so it can be displayed...
	$params->{VERSION}=$VERSION;

	# Show the main WebLogger config webpage...
	# (it is our only page for now)
	my $template=Slim::Web::HTTP::filltemplatefile($template_to_show,$params);
	return($template);
}

1;
