package Plugins::WebLogger;

# Plugin for Slimdevices SlimServer software that updates a file/script on the
# web with information about the currently playing song everytime a new song
# is listened to.
#
# Copyright (C) 2004 Danny Rego (danny@rego.com)
#
# This code is derived from code with the following copyright message:
#
# SliMP3 Server Copyright (C) 2001 Sean Adams, Slim Devices Inc.
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License,
# version 2.

use Slim::Control::Command;
use Slim::Utils::Strings qw (string);
use Slim::Utils::Timers;
use Slim::Hardware::VFD;
use File::Spec::Functions qw(:ALL);
use FindBin qw($Bin);
use Slim::Music::Info;
use Slim::Buttons::Common;
use LWP::UserAgent;
use HTTP::Request::Common qw(POST GET);
use URI::Escape;
use File::Temp;
use Net::FTP;

use strict;

use vars qw($VERSION);
$VERSION = 0.03;

# Points slimserver to the display name for this plugin...
sub getDisplayName() {return string('PLUGIN_WEBLOGGER_TITLE');}

# Contains all strings for this plugin, in all languages...
# (by using the string() function, translation is taken care of for us)
sub strings() { return '
PLUGIN_WEBLOGGER_TITLE
	EN	Web Logger
PLUGIN_WEBLOGGER_ERROR_TITLE
	EN	Web Logger Error
PLUGIN_WEBLOGGER_STATUS
	EN	Status
PLUGIN_WEBLOGGER_CONFIG
	EN	Configuration
PLUGIN_WEBLOGGER_CONFIG_LOG_TITLE
	EN	Log Song Title?
PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUM
	EN	Log Album Name?
PLUGIN_WEBLOGGER_CONFIG_LOG_ARTIST
	EN	Log Artist/Band Name?
PLUGIN_WEBLOGGER_CONFIG_LOG_TIMESTAMP
	EN	Log Timestamp?
PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUMART
	EN	Log Album Art?
PLUGIN_WEBLOGGER_CONFIG_LOG_YES
	EN	Log
PLUGIN_WEBLOGGER_CONFIG_LOG_HIDDEN
	EN	Log (in mouse-over)
PLUGIN_WEBLOGGER_CONFIG_LOG_NO
	EN	Do not log
PLUGIN_WEBLOGGER_ABOUT
	EN	About Web Logger
PLUGIN_WEBLOGGER_ABOUT_INFO
	EN	Written By: Danny Rego (danny@rego.com - http://www.regoroad.com)
PLUGIN_WEBLOGGER_ENABLED
	EN	Enabled
PLUGIN_WEBLOGGER_DISABLED
	EN	Disabled
PLUGIN_WEBLOGGER_CONFIG_URL
	EN	URL to Write To
PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD
	EN	HTTP Method of Submission
PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_GET
	EN	Submit using "get"
PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_POST
	EN	Submit using "post"
PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_MULTIPARTPOST
	EN	Submit using "multipart post"
PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK
	EN	HTTP Check for "OK" in response
PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK_ENABLED
	EN	Yes
PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK_DISABLED
	EN	No
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_TYPE
	EN	Album Art Style
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_THUMBNAIL
	EN	Yes (thumbail)
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ARTWORK
	EN	Yes (artwork)
PLUGIN_WEBLOGGER_CONFIG_INFO_FILENAME
	EN	Information Filename
PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME
	EN	Album Art Filename
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT
	EN	Timeout
PLUGIN_WEBLOGGER_CONFIG_FORMAT
	EN	Format
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT
	EN	Timeout
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_1
	EN	1 Second
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_2
	EN	2 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_5
	EN	5 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_10
	EN	10 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_15
	EN	15 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_30
	EN	30 Seconds
PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_60
	EN	60 Seconds
PLUGIN_WEBLOGGER_CONFIG_FORMAT
	EN	Output Format
PLUGIN_WEBLOGGER_CONFIG_FORMAT_TEXT
	EN	Text
PLUGIN_WEBLOGGER_CONFIG_FORMAT_HTML
	EN	HTML
PLUGIN_WEBLOGGER_CONFIG_FORMAT_TABLE
	EN	HTML Table
PLUGIN_WEBLOGGER_CONFIG_FORMAT_XML
	EN	XML
PLUGIN_WEBLOGGER_CONFIG_FORMAT_TEMPLATE
	EN	Custom Template
PLUGIN_WEBLOGGER_CONFIG_TEMPLATE_FILENAME
	EN	Custom Template Filename
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE
	EN	Keep FTP connection open?
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_ENABLED
	EN	Yes
PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_DISABLED
	EN	No
'};

# Hash to keep settings of multiple squeezeboxes seperate...
my %active_client_list;
my $plugin_handle='weblogger';

# Definition of our config menu structure, and input items...
my %menuParams = (
	$plugin_handle => {
		'listRef' =>
			[
				'PLUGIN_WEBLOGGER_STATUS'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_TITLE'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUM'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_ARTIST'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_TIMESTAMP'
				,'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUMART'
				,'PLUGIN_WEBLOGGER_CONFIG_URL'
				,'PLUGIN_WEBLOGGER_CONFIG_INFO_FILENAME'
				,'PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD'
				,'PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK'
				,'PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE'
				,'PLUGIN_WEBLOGGER_CONFIG_FORMAT'
				,'PLUGIN_WEBLOGGER_CONFIG_TEMPLATE_FILENAME'
				,'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_TYPE'
				,'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME'
				,'PLUGIN_WEBLOGGER_CONFIG_TIMEOUT'
				,'PLUGIN_WEBLOGGER_ABOUT'
			]
		,'stringExternRef' => 1
		,'header' => 'PLUGIN_WEBLOGGER_TITLE'
		,'stringHeader' => 1
		,'headerAddCount' => 1
		,'callback' => \&menuTransitionHandler
		,'overlayRef' => sub {return (undef,Slim::Hardware::VFD::symbol('rightarrow'));}
		,'overlayRefArgs' => ''
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_STATUS') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0,1]
		,'externRef' => ['PLUGIN_WEBLOGGER_DISABLED','PLUGIN_WEBLOGGER_ENABLED']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_TITLE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'status'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'status'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_URL') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_URL'
		,'initialValue' => sub { _getParam($_[0],'config_url'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_url'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['GET','POST','MULTIPARTPOST']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_GET','PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_POST','PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD_MULTIPARTPOST']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_HTTP_METHOD'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_http_method'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_http_method'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0,1]
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK_DISABLED','PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK_ENABLED']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_HTTP_CHECKFOROK'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_http_checkforok'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_config_http_checkforok'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_TYPE') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['THUMB','COVER']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_ALBUMART_THUMBNAIL','PLUGIN_WEBLOGGER_CONFIG_ALBUMART_ARTWORK']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_TYPE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_albumart_type'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_albumart_type'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_ALBUMART_FILENAME'
		,'initialValue' => sub { _getParam($_[0],'config_albumart_filename'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_albumart_filename'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_INFO_FILENAME') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_TITLE'
		,'initialValue' => sub { _getParam($_[0],'config_info_filename'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_info_filename'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_TIMEOUT') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [1,2,5,10,15,30,60]
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_1','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_2','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_5','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_10','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_15','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_30','PLUGIN_WEBLOGGER_CONFIG_TIMEOUT_60']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_TIMEOUT'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_timeout'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_timeout'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_FORMAT') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['Text','HTML','Table','XML','Template']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_FORMAT_TEXT','PLUGIN_WEBLOGGER_CONFIG_FORMAT_HTML','PLUGIN_WEBLOGGER_CONFIG_FORMAT_TABLE','PLUGIN_WEBLOGGER_CONFIG_FORMAT_XML','PLUGIN_WEBLOGGER_CONFIG_FORMAT_TEMPLATE']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_FORMAT'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_format'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_format'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_TEMPLATE_FILENAME') => {
		'useMode' => 'INPUT.Text'
		,'charsRef' => 'BOTH'
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_TEMPLATE_FILENAME'
		,'initialValue' => sub { _getParam($_[0],'config_template_filename'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_template_filename'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_LOG_TITLE') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','HIDDEN','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_HIDDEN','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_TITLE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_title'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_title'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUM') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','HIDDEN','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_HIDDEN','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUM'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_album'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_album'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_LOG_ARTIST') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','HIDDEN','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_HIDDEN','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_ARTIST'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_artist'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_artist'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_LOG_TIMESTAMP') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','HIDDEN','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_HIDDEN','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_TIMESTAMP'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_timestamp'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_timestamp'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUMART') => {
		'useMode' => 'INPUT.List'
		,'listRef' => ['YES','NO']
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_LOG_YES','PLUGIN_WEBLOGGER_CONFIG_LOG_NO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_LOG_ALBUMART'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_log_albumart'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_log_albumart'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0,1]
		,'externRef' => ['PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_DISABLED','PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE_ENABLED']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_CONFIG_FTP_KEEPALIVE'
		,'stringHeader' => 1
		,'initialValue' => sub { _getParam($_[0],'config_ftp_keepalive'); }
		,'callback' => sub{ inputCallback($_[0], $_[1], 'config_ftp_keepalive'); }
	}
	,catdir($plugin_handle,'PLUGIN_WEBLOGGER_ABOUT') => {
		'useMode' => 'INPUT.List'
		,'listRef' => [0]
		,'externRef' => ['PLUGIN_WEBLOGGER_ABOUT_INFO']
		,'stringExternRef' => 1
		,'headerString' => 'PLUGIN_WEBLOGGER_ABOUT'
		,'stringHeader' => 1
	}
);

sub setMode {
	my $client = shift;
	my $method = shift;

	# This is called whenever this plugin's config menu is entered from the main plugins menu...

	if ($method eq 'pop') {
		# We get here when we exit back out to the main plugins menu...
		# (by hitting the "left" button)
		Slim::Buttons::Common::popModeRight($client);
		return;
	}

	# Tell our menu hash to start at the main menu, and tell it which client we're configuring...
	my %params = %{$menuParams{$plugin_handle}};
	$params{'valueRef'} = \$active_client_list{$client}{activemenu};
	Slim::Buttons::Common::pushMode($client,'INPUT.List',\%params);
	$client->update();
}

sub menuTransitionHandler {
	my ($client,$exittype) = @_;

	# Called whenever the menu/item changes so that it can handle the transition effect...
	# (and, as it happens...setup default values that can't be set in the hash)
	# (some values CAN be set in the hash for some types, and not others, so we set them ALL up here so the hash can be defined consistantly for all types)

	$exittype = uc($exittype);
	if ($exittype eq 'LEFT') {
		# Called when exiting back to the main plugins menu...
		Slim::Buttons::Common::popModeRight($client);
	} elsif ($exittype eq 'RIGHT') {
		# Entering a sub-menu/sub-item...
		my $nextmenu = catdir($plugin_handle,$active_client_list{$client}{activemenu});
		if (exists($menuParams{$nextmenu})) {
			my %nextParams = %{$menuParams{$nextmenu}};
			if ($nextParams{'useMode'} eq 'INPUT.List') {
				# We are entering a list input specifically...

				if(exists($nextParams{'initialValue'})) {
					# Make sure it's preference value is set to what it currently is, or the default...
					my $value;
					if (ref($nextParams{'initialValue'}) eq 'CODE') {
						# Retrieve the value from the specified function...
						$value = $nextParams{'initialValue'}->($client);
					} else {
						# Reload it's initial value (usually from prefs file...specifid in embedded sub)...
						$value = _getParam($client,$nextParams{'initialValue'},1);
					}
					$nextParams{'valueRef'} = \$value;
				}

				if(exists($nextParams{'headerString'})) {
					# Set the header by our strings table...
					$nextParams{'header'}=string($nextParams{'headerString'});
				}

			} elsif ($nextParams{'useMode'} eq 'INPUT.Text') {
				# We are entering a text input specifically...

				if(exists($nextParams{'initialValue'})) {
					# Make sure it's preference value is set to what it currently is, or the default...
					my $value;
					if (ref($nextParams{'initialValue'}) eq 'CODE') {
						# Retrieve the value from the specified function...
						$value = $nextParams{'initialValue'}->($client);
					} else {
						# Reload it's initial value (usually from prefs file...specifid in embedded sub)...
						$value = _getParam($client,$nextParams{'initialValue'},1);
					}
					$nextParams{'valueRef'} = \$value;
				}

				if(exists($nextParams{'headerString'})) {
					# Set the header by our strings table...
					$nextParams{'header'}=string($nextParams{'headerString'});
				}

			}
			Slim::Buttons::Common::pushModeLeft(
				$client
				,$nextParams{'useMode'}
				,\%nextParams
			);
		} else {
			# We are trying to enter a menu that doesn't exist...
			# (just bump, and redisplay same menu, so some activity is shown at least)
			Slim::Display::Animation::bumpRight($client);
		}
	} else {
		# ...should never make it here...
		return;
	}
}

sub _getParam
{
	my($client,$prefName,$isFullName)=@_;

	# Reads a preference for this plugin from the main pref file, and if it's not set yet, returns the specified default...

	# These are our defaults for any uninitialized vars...
	my %defaults=(
		status				=> 0,
		config_log_title		=> 'YES',
		config_log_album		=> 'YES',
		config_log_artist		=> 'YES',
		config_log_timestamp		=> 'YES',
		config_log_albumart		=> 'YES',
		config_url			=> 'file://c:\\',
		config_info_filename		=> 'songinfo.txt',
		config_http_method		=> 'POST',
		config_http_checkforok		=> 1,
		config_format			=> 'Table',
		config_template_filename	=> 'WebLogger.template.txt',
		config_albumart_type		=> 'THUMB',
		config_albumart_filename	=> 'albumart.jpg',
		config_ftp_keepalive		=> 1,
		config_timeout			=> 5
	);

	my $returnValue;
	if($isFullName) {
		# The name passed in isn't necessarily a plugin var...it could be anything, so don't prefix the plugin handle...
		$returnValue=Slim::Utils::Prefs::clientGet($client,$prefName) || $defaults{$prefName};
	} else {
		# Get the value of the preference...it's stored as part of the plugin's prefs...
		$returnValue=Slim::Utils::Prefs::clientGet($client,$plugin_handle.'_'.$prefName) || $defaults{$prefName};
	}

	return($returnValue);
}

sub _setParam
{
	my($client,$prefName,$value,$isFullName)=@_;

	# Writes a preference for this plugin to the main preference file...

	if($isFullName) {
		# The name passed in isn't necessarily a plugin var...it could be anything, so don't prefix the plugin handle...
		return(Slim::Utils::Prefs::clientSet($client,$prefName,withoutEscapes($value)));
	}

	# Set the value of the preference...it's stored as part of the plugin's prefs...
	return(Slim::Utils::Prefs::clientSet($client,$plugin_handle.'_'.$prefName,withoutEscapes($value)));
}

sub inputCallback {
	my ($client,$type,$param_key) = @_;

	# Called when the input item is trying to exit...it's up to us to decide what to do at that point...

	my $nextmenu = catdir($plugin_handle,$active_client_list{$client}{activemenu});
	if (exists($menuParams{$nextmenu})) {
		my %nextParams = %{$menuParams{$nextmenu}};

		# Get the entered value (without the trailing control characters that show the arrows etc...
		my $valueRef=${Slim::Buttons::Common::param($client,'valueRef')};
		$valueRef=~s/vfD\_.+\_Vfd//gs;

		if ($nextParams{'useMode'} eq 'INPUT.List') {
			# left OR right - It doesn't matter, just store it
			if(($type eq 'left')||($type eq 'right')) {
				# It doesn't matter how they leave, store what they left it at...
				_setParam($client,$param_key,$valueRef);
			}
		} elsif($nextParams{'useMode'} eq 'INPUT.Text') {
			if($type eq 'backspace') {
				# They are cancelling out of the text input...
				# (leave it alone)
			} elsif($type eq 'nextChar') {
				# In essence, they've hit enter...
				_setParam($client,$param_key,$valueRef);
			}
		}
	}

	Slim::Buttons::Common::popModeRight($client);
}

###############################################################################
#
# Everything ABOVE this line defines the config menu for this plugin...
#
# Everything BELOW this line is what makes the plugin work...
#
###############################################################################

sub _errorOut
{
	my($errormessage)=@_;
	$@=$errormessage;
	return(0);
}

sub parseSubmissionURL
{
	my($url)=@_;
	my %paramlist;

	# Breaks a URL down into the actual URL, and any params that might be in there...
	# (returns them seperated as a STRING, and HASHREF)

	if($url=~/(.*)\?([^?]+)/) {
		my $params;
		($url,$params)=($1,$2);
		foreach my $paramstring (split(/[?&]+/,$params)) {
			if($paramstring=~/^([^=]*)=([^=]*)$/) {
				$paramlist{$1}=uri_unescape($2);
			}
		}
	}
	return($url,\%paramlist);
}

sub withoutEscapes
{
	my($line)=@_;
# XXX - There has to be a better/more proper way to do this...
	# Old-style escapes...
	$line=~s/\_\_[^\_]+\_\_//gmi;
	# New-style escapes...
	$line=~s/\x1e[^?]+\x1e//gmi;
	# Get rid of the right arrow escape that might be there from the input...
	my $ra_char=Slim::Display::Display::symbol('rightarrow');
	$line=~s/$ra_char//gmi;
	return($line);
}

sub _getTimestamp
{
	my($client)=@_;
	my @datelines=Slim::Buttons::Common::dateTime($client);
	my $timestamp="$datelines[0] $datelines[1]";
	return(withoutEscapes($timestamp));
}

sub _storeSongInfo
{
	my($client,$songinfo)=@_;

	# Stores the song information (minus the timestamp) we've just updated
	# with so that we can check to see if it's changed on the next update
	# attempt...('cause if it's the same, we shouldn't bother then)

	$active_client_list{$client}{lastsonginfo}={};
	foreach my $key (keys(%$songinfo)) {
		next if($key eq 'TIMESTAMP');
		$active_client_list{$client}{lastsonginfo}{$key}=$songinfo->{$key};
	}
}

sub _songInfoChanged
{
	my($client,$songinfo)=@_;

	# Checks to see if the song information we're going to update to is different from what was written on the last update...
	# (ignoring the TIMESTAMP field as that changes every second)

	$active_client_list{$client}{lastsonginfo}={} if(!exists($active_client_list{$client}{lastsonginfo}));
	foreach my $key (keys(%$songinfo)) {
		next if($key eq 'TIMESTAMP');
		if((!exists($active_client_list{$client}{lastsonginfo}{$key}))||($songinfo->{$key} ne $active_client_list{$client}{lastsonginfo}{$key})) {
			return(1);
		}
	}

	# Nothing's changed...it looks the same...
	return(0);
}

sub _getAllLogItems
{
	my($client)=@_;
	my @logitems;
	my @checklist=('title','album','artist','timestamp','albumart');

	foreach my $key (@checklist) {
		if(uc(_getParam($client,'config_log_'.$key)) ne 'NO') {
			push(@logitems,uc($key));
		}
	}

	return(@logitems);
}

sub _getLogItems
{
	my($client)=@_;
	my @logitems;
	my @checklist=('title','album','artist','timestamp','albumart');

	foreach my $key (@checklist) {
		if(uc(_getParam($client,'config_log_'.$key)) eq 'YES') {
			push(@logitems,uc($key));
		}
	}

	return(@logitems);
}

sub _getHiddenLogItems
{
	my($client)=@_;
	my @logitems;
	my @checklist=('title','album','artist','timestamp','albumart');

	foreach my $key (@checklist) {
		if(uc(_getParam($client,'config_log_'.$key)) eq 'HIDDEN') {
			push(@logitems,uc($key));
		}
	}

	return(@logitems);
}

sub _loadAlbumArt
{
	my($client,$artfilename)=@_;
	my $graphic=undef;
	if(open(ALBUMARTFH,"< $artfilename")) {
		undef $/;
		binmode ALBUMARTFH;
		$graphic=<ALBUMARTFH>;
		close(ALBUMARTFH);
	}
	return($graphic);
}

sub _getMouseOverText
{
	my($client,$songinfo)=@_;
	my @hiddenItems=_getHiddenLogItems($client);
	if(scalar(@hiddenItems)>0) {
		# This HTML will contain some mouse-over stuff...
		my $mouseover_output;
		$mouseover_output.="Song: $songinfo->{TITLE}\n" if(grep(/TITLE/i,@hiddenItems));
		$mouseover_output.="Album: $songinfo->{ALBUM}\n" if(grep(/ALBUM/i,@hiddenItems));
		$mouseover_output.="Artist: $songinfo->{ARTIST}\n" if(grep(/ARTIST/i,@hiddenItems));
		$mouseover_output.="Last Updated: $songinfo->{TIMESTAMP}\n" if(grep(/TIMESTAMP/i,@hiddenItems));
		$mouseover_output=~s/[\n\r]+$//;
		return($mouseover_output);
	}
	return(undef);
}

sub _songInfoAsFileHTML
{
	my($client,$songinfo)=@_;
	my @displayItems=_getLogItems($client);
	my $output='';

	$output.="<img src=\""._getParam($client,'config_albumart_filename')."\"><br>\n" if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART})));
	$output.="<b>Song:</b></a> $songinfo->{TITLE}<br>\n" if(grep(/TITLE/i,@displayItems));
	$output.="<b>Album:</b> $songinfo->{ALBUM}<br>\n" if(grep(/ALBUM/i,@displayItems));
	$output.="<b>Artist:</b> $songinfo->{ARTIST}<br>\n" if(grep(/ARTIST/i,@displayItems));
	$output.="<b>Last Updated:</b> $songinfo->{TIMESTAMP}<br>\n" if(grep(/TIMESTAMP/i,@displayItems));

	# Add mouse-over text if any...
	my $mouseover_output=_getMouseOverText($client,$songinfo);
	if($mouseover_output) {
		$output="<span title=\"$mouseover_output\">".$output."</span>";
	}

	return($output);
}

sub _songInfoAsFileHTMLTable
{
	my($client,$songinfo)=@_;
	my @displayItems=_getLogItems($client);
	my $entrycount=scalar(@displayItems);
	my $output='';

	if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))) {
		# Graphic to be included...
		$output="<table><tr><td valign=\"top\" rowspan=\"$entrycount\"><img src=\"/"._getParam($client,'config_albumart_filename')."\"></td></tr>\n";
	} else {
		# No graphic...
		$output="<table>";
	}
	$output.="<tr><td valign='top' nowrap><b>Song</b></td><td valign=\"top\">$songinfo->{TITLE}</td></tr>\n" if(grep(/TITLE/i,@displayItems));
	$output.="<tr><td valign='top' nowrap><b>Album</b></td><td valign=\"top\">$songinfo->{ALBUM}</td></tr>\n" if(grep(/ALBUM/i,@displayItems));
	$output.="<tr><td valign='top' nowrap><b>Artist</b></td><td valign=\"top\">$songinfo->{ARTIST}</td></tr>\n" if(grep(/ARTIST/i,@displayItems));
	$output.="<tr><td valign='top' nowrap><b>Last Updated</b></td><td valign=\"top\">$songinfo->{TIMESTAMP}</td></tr>\n" if(grep(/TIMESTAMP/i,@displayItems));
	$output.="</table>\n";

	# Add mouse-over text if any...
	my $mouseover_output=_getMouseOverText($client,$songinfo);
	if($mouseover_output) {
		$output="<span title=\"$mouseover_output\">".$output."</span>";
	}

	return($output);
}

sub _songInfoAsFileText
{
	my($client,$songinfo)=@_;
	my $output='';

	$output.="Song: $songinfo->{TITLE}\n" if(exists($songinfo->{TITLE}));
	$output.="Album: $songinfo->{ALBUM}\n" if(exists($songinfo->{ALBUM}));
	$output.="Artist: $songinfo->{ARTIST}\n" if(exists($songinfo->{ARTIST}));
	$output.="Last Updated: $songinfo->{TIMESTAMP}\n" if(exists($songinfo->{TIMESTAMP}));

	# Skip the graphic because there's no way to display it in a TXT file?!

	return($output);
}

sub _songInfoAsFileXML
{
	my($client,$songinfo)=@_;

	use XML::Simple;
	my $output=XMLout({SONG => $songinfo});

	return($output);
}

sub _songInfoAsFileTemplate
{
	my($client,$songinfo)=@_;

	# Get template filename...
	my $templatefilename=$Bin.'/Plugins/'._getParam($client,'config_template_filename');

	# Read it in....
	my $template;
	if(open(ALBUMARTFH,"< $templatefilename")) {
		undef $/;
		binmode ALBUMARTFH;
		$template=<ALBUMARTFH>;
		close(ALBUMARTFH);
	} else {
		# If it can't be read...return an error...
		return("No template found at \"$templatefilename\".");
	}

	# Do some search & replace...
	foreach my $key (keys(%$songinfo)) {
		$template=~s/{{$key}}/$songinfo->{$key}/gsi;
	}

	# Blank out any vars that they might have de-selected...
	$template=~s/{{[^{}]+}}//gsi;

	return($template);
}

sub getSongAsFile
{
	my($client,$songinfo)=@_;
	my $output='';
	my $containsfiles=0;

	# Get our "file" contents ready for output...
	my $output_style=uc(_getParam($client,'config_format'));
	if($output_style eq 'HTML') {
		$output=_songInfoAsFileHTML($client,$songinfo);
	} elsif($output_style eq 'TABLE') {
		$output=_songInfoAsFileHTMLTable($client,$songinfo);
	} elsif($output_style eq 'XML') {
		$output=_songInfoAsFileXML($client,$songinfo);
		$containsfiles=1;
	} elsif($output_style eq 'TEMPLATE') {
		$output=_songInfoAsFileTemplate($client,$songinfo);
	} else {
		$output=_songInfoAsFileText($client,$songinfo);
	}

	return($output,$containsfiles);
}

sub getSongData
{
	my($client,$tempfileurl)=@_;
	my @logitems=_getAllLogItems($client);
	my %newinfo;

	# Load all of the information about this song that we've got, and might be using...

	# Make a new hash that we can manipulate without screwing up database data...
	# ('cause we need to add the timestamp, and who knows what else in the future)

	# Get the tag information that we want for the specified file, and store it in our hash...
	my $songinfo=Slim::Music::Info::readTags($tempfileurl);
	foreach my $item (@logitems) {
		if($item eq 'TIMESTAMP') {
			$newinfo{$item}=_getTimestamp($client);
		} elsif($item eq 'ALBUMART') {
			# They've specified that they want the album art uploaded...
			# Add the graphic they've requested...
			my $albumarttype=uc(_getParam($client,'config_albumart_type'));
			if(exists($songinfo->{$albumarttype})) {
				$newinfo{ALBUMART}=_loadAlbumArt($client,$songinfo->{$albumarttype});
			} else {
				$newinfo{ALBUMART}=undef;
			}
		} else {
			$newinfo{$item}=$songinfo->{$item};
		}
	}

	return(\%newinfo);
}

sub _loginFTP
{
	my($client,$server,$username,$password,$filepath)=@_;

	# Opens our FTP session, and navigates us to the directory where we need to send the files...
	# (caches the connection if the keepalive flag is set for fast updates)

# XXX - Whenever our config has changed we should login again (logout at least)...

	if((exists($active_client_list{$client}{openftp}))&&(defined($active_client_list{$client}{openftp}))) {
		# FTP should still be alive!?  (what if we were kicked out?!)
		# Test to see if we're still logged in by issuing a useless command...
		if($active_client_list{$client}{openftp}->cwd($filepath)) {
			# Return our working FTP handle..
			return($active_client_list{$client}{openftp});
		} # else we were disconnected...so continue on, so we can login again...
	}

	# If we've made it here...we need to create an FTP session, and login with the provided info...
	$active_client_list{$client}{openftp}=new Net::FTP($server, Debug => 0);
	if(!$active_client_list{$client}{openftp}) {
		die("Bad server: $server");
	}

	# Login without our specified info...
	if(!$active_client_list{$client}{openftp}->login($username,$password)) {
		die($active_client_list{$client}{openftp}->message());
	}

	# Go to the specified sub-directory...
	if(($filepath)&&(!$active_client_list{$client}{openftp}->cwd($filepath))) {
		die($active_client_list{$client}{openftp}->message());
	}

	# Successful...return the object for use...
	return($active_client_list{$client}{openftp});
}

sub _logoutFTP
{
	my($client)=@_;

	# Logs out, and kills our FTP session unless the keepalive flag is set...

	if((!exists($active_client_list{$client}{openftp}))||(!defined($active_client_list{$client}{openftp}))) {
		# No ftp connection, so don't bother logging out...
		return;
	}

	if(_getParam($client,'config_ftp_keepalive')) {
		# They want to keep the FTP connection alive...so don't quit...
		# (leave it open, and ready for the next call)
		return;
	}

	# We're done with FTP...log out nicely...
	if(!$active_client_list{$client}{openftp}->quit()) {
		die($active_client_list{$client}{openftp}->message());
	}

	# We don't undef the reference to the FTP object, because it helps GREATLY for
	# speed if we don't have to re-init a new FTP object everytime...
	# $active_client_list{$client}{openftp}=undef;

	return;
}


sub _updateByFTP
{
	my($client,$songinfo,$url,$timeout)=@_;

	# Rips the specified URL apart into the bits we need...
	my ($username,$password,$server,$filepath)=();
	if($url=~/^ftp:\/\/(.*):(.*)@([^\\\/]*)([\\\/].*)?[\\\/]?$/i) {
		$username=uri_unescape($1 || '');
		$password=uri_unescape($2 || '');
		$server=uri_unescape($3 || '');
		$filepath=uri_unescape($4 || '');
	} else {
		return(_errorOut("Bad URL: $url"));
	}

	# Let's do the actual FTP now that we have our info...
	my $ftp;
	eval
	{
		# Set the timer...
		local $SIG{ALRM}=sub{die "$timeout second limit reached"};
		alarm($timeout);

		# Get our FTP object to where we need to be logged in...
		my $ftp=_loginFTP($client,$server,$username,$password,$filepath);

		# Let's just send everything as a binary type...the worst that can happen is
		# extra/missing CR/LF characters depending what type of machine we're transferring between...
		if(!$ftp->binary()) {
			die($ftp->message());
		}

		# Make a list of files to upload (we already have them in memory, so we have to fudge some stuff)
		my %files;
		my($songfile,$containsfiles)=getSongAsFile($client,$songinfo);
		$files{_getParam($client,'config_info_filename')}=$songfile;
		$files{_getParam($client,'config_albumart_filename')}=$songinfo->{ALBUMART} if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))&&(!$containsfiles));

		foreach my $filename (keys(%files)) {
			my $tempfile; # Asking for undef doesn't actually open the file...it just gives us a temp filename to use. 
			(undef,$tempfile)=File::Temp::tempfile();

			# Write to our temporary file...
			open(TEMPFILEFH,"> $tempfile");
			binmode TEMPFILEFH;
			print TEMPFILEFH $files{$filename};
			close(TEMPFILEFH);

			# Now send the temporary file to the FTP site, but name it properly...
			if(!$ftp->put($tempfile,$filename)) {
				die($ftp->message());
			}

			# We're done with our temporary file...
			unlink($tempfile);
		}

		# We're done with FTP (for now)...
		_logoutFTP($client);

		# Kill the timer...
		alarm(0);
	};

	if($@) {

		# We need to kill the timer just incase we died out, and skipped the reset...
		# Otherwise, the timer could still go off, and cause the server to die...
		alarm(0);
		return(_errorOut("$@"));
	}

	return(1);
}

sub _updateByLocalFile
{
	my($client,$songinfo,$url,$timeout)=@_;

	# Get rid of the file::/ if any...
	my($filepath)=();
	if($url=~/^file:\/\/(.*)[\\\/]?/) {
		$filepath=$1 || '';
	} else {
		return(_errorOut("Could not parse specified URL.  ($url)"));
	}

	# Make a list of files to upload (we already have them in memory, so we have to fudge some stuff)
	my %files;
	my($songfile,$containsfiles)=getSongAsFile($client,$songinfo);
	$files{_getParam($client,'config_info_filename')}=$songfile;
	$files{_getParam($client,'config_albumart_filename')}=$songinfo->{ALBUMART} if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))&&(!$containsfiles));

	foreach my $filename (keys(%files)) {
		# Write out file...
		if(open(FILEOUTPUTFH,"> $filepath/$filename")) {
			binmode FILEOUTPUTFH;
			print FILEOUTPUTFH $files{$filename};
			close(FILEOUTPUTFH);
		} else {
			return(_errorOut("Could not write to \"$filepath/$filename\"."));
		}
	}

	return(1);
}

sub _updateByHTTPMultipartPost
{
	my($client,$songinfo,$url,$paramlist,$timeout)=@_;

	# Make a list of files to upload (we already have them in memory, so we have to fudge some stuff)
	my %files;
	my($songfile,$containsfiles)=getSongAsFile($client,$songinfo);
	$files{_getParam($client,'config_info_filename')}=$songfile;
	$files{_getParam($client,'config_albumart_filename')}=$songinfo->{ALBUMART} if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))&&(!$containsfiles));

	# Prepare our HTTP request...
	my $request=POST $url, Content_Type => 'form-data', Content => [%$paramlist, %files];

	# Create our UserAgent, and send the file/params...
	# (submit our faked "form" data)
	my $ua = LWP::UserAgent->new;
	$ua->parse_head(0);	# Slimserver does not include the HTML::HeadeParser module(s)...
	$ua->timeout($timeout);
	my $response=$ua->simple_request($request);
	if($response->is_error()) {
		my $errorCode=$response->code;
		my $errorMessage=$response->message;
		$errorMessage='Connection timed out.' if(($errorCode==500)&&(!$errorMessage));
		return(_errorOut("$errorMessage (#$errorCode)"));
	}

	# Check for, and return an error, or continue on if successful...
	my $content=$response->content;
	if((_getParam($client,'config_http_checkforok'))&&($content!~/^OK/)) {
		return(_errorOut($content));
	}

	return(1);
}

sub _updateByHTTPPost
{
	my($client,$songinfo,$url,$paramlist,$timeout)=@_;

	# Add song information if it's not to be sent as a file type...
	# Add the one hash to the other...now we're ready to submit...
	foreach my $infokey (keys(%$songinfo)) {
		next if($infokey=~/^ALBUMART/);
		$paramlist->{$infokey}=$songinfo->{$infokey};
	}

	# Prepare our HTTP request...
	my $request=POST $url, [%$paramlist];

	# Create our UserAgent, and send the file/params...
	# (submit our faked "form" data)
	my $ua = LWP::UserAgent->new;
	$ua->parse_head(0);	# Slimserver does not include the HTML::HeadeParser module(s)...
	$ua->timeout($timeout);
	my $response=$ua->simple_request($request);
	if($response->is_error()) {
		my $errorCode=$response->code;
		my $errorMessage=$response->message;
		$errorMessage='Connection timed out.' if(($errorCode==500)&&(!$errorMessage));
		return(_errorOut("HTTP Error #$errorCode: $errorMessage"));
	}

	# Check for, and return an error, or continue on if successful...
	my $content=$response->content;
	if((_getParam($client,'config_http_checkforok'))&&($content!~/^OK/)) {
		return(_errorOut($content));
	}

	# If they want the graphic sent...return an error because there's no way to do it via GET...
	if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))) {
		return(_errorOut("Album art upload via standard POST not possible.  (Use \"multipart post\" instead)"));
	}

	return(1);
}

sub _updateByHTTPGet
{
	my($client,$songinfo,$url,$paramlist,$timeout)=@_;

	# Add song information if it's not to be sent as a file type...
	# Add the one hash to the other...now we're ready to submit...
	foreach my $infokey (keys(%$songinfo)) {
		next if($infokey=~/^ALBUMART/);
		$paramlist->{$infokey}=$songinfo->{$infokey};
	}

	# Rebuild URL with the params that have been added to etc...
	$url.='?';
	foreach my $key (keys(%$paramlist)) {
		$url.=$key."=".uri_escape($paramlist->{$key})."&";
	}

	# Prepare our HTTP request...
	my $request=GET $url;

	# Create our UserAgent, and send the file/params...
	# (submit our faked "form" data)
	my $ua = LWP::UserAgent->new;
	$ua->parse_head(0);	# Slimserver does not include the HTML::HeadeParser module(s)...
	$ua->timeout($timeout);
	my $response=$ua->simple_request($request);
	if($response->is_error()) {
		my $errorCode=$response->code;
		my $errorMessage=$response->message;
		$errorMessage='Connection timed out.' if(($errorCode==500)&&(!$errorMessage));
		return(_errorOut("$errorMessage (#$errorCode)"));
	}

	# Check for, and return an error, or continue on if successful...
	my $content=$response->content;
	if((_getParam($client,'config_http_checkforok'))&&($content!~/^OK/)) {
		return(_errorOut($content));
	}

	# If they want the graphic sent...return an error because there's no way to do it via GET...
	if((exists($songinfo->{ALBUMART}))&&(defined($songinfo->{ALBUMART}))) {
		return(_errorOut("Album art upload via GET not possible."));
	}

	return(1);
}

sub updateBlog
{
	my($client,$tempfileurl)=@_;

	# Stores the song info on the specified server...

	# Don't do this unless it's enabled in the config...
	return(1) if(_getParam($client,'status')!=1);

	# Display text temporarily to let them know why it's paused (if it has at all)...
	Slim::Display::Animation::showBriefly($client,string('PLUGIN_WEBLOGGER_TITLE'),'Updating song information...',0);

	# Get all of the song information that is selected for updating...
	my $songinfo=getSongData($client,$tempfileurl);

	# If nothing's changed since the last update...don't bother updating again...
	if(!_songInfoChanged($client,$songinfo)) {
		# Nothing's changed...skip the update...
		return(1);
	}

	# We need a timeout incase an update takes forever...
	# (we can't use ALARM because something else uses it within LWP, and it cancels our out)
	my $TIMEOUT=uc(_getParam($client,'config_timeout'));

	# Get our submission URL, and vars to pass in, and do it...
	my $url=_getParam($client,'config_url');
	if($url=~/^ftp:\/\//i) {
		# Send file to FTP site...
		if(!_updateByFTP($client,$songinfo,$url,$TIMEOUT)) {
			return(_errorOut($@));
		}
	} elsif($url=~/^https?:\/\//i) {
		# Submit as HTTP GET/POST to a script...

		# Rip out all specified params...
		my $paramlist;
		($url,$paramlist)=parseSubmissionURL($url);

		my $method=uc(_getParam($client,'config_http_method'));
		if($method eq 'MULTIPARTPOST') {
			# POST as file...
			if(!_updateByHTTPMultipartPost($client,$songinfo,$url,$paramlist,$TIMEOUT)) {
				return(_errorOut($@));
			}
		} elsif($method eq 'POST') {
			# POST just params...
			if(!_updateByHTTPPost($client,$songinfo,$url,$paramlist,$TIMEOUT)) {
				return(_errorOut($@));
			}
		} else {
			if(!_updateByHTTPGet($client,$songinfo,$url,$paramlist,$TIMEOUT)) {
				return(_errorOut($@));
			}
		}
	} else {
		# Text file output...
		if(!_updateByLocalFile($client,$songinfo,$url,$TIMEOUT)) {
			return(_errorOut($@));
		}
	}

	# The update is done...keep track of the songinfo to minimize un-necessary updates...
	_storeSongInfo($client,$songinfo);

	# All is well...we're done...
	return(1);	
}

sub commandCallback
{
	my($client,$paramsRef)=@_;

	if($paramsRef->[0] eq 'open') {

		# A new song is about to be played...
		# Get the currently playing song, and it's tag information, and write it where specified...

		if(!updateBlog($client,$paramsRef->[1])) {
			# There was an error, so display it...we can't use showBriefly() in the
			# normal way because we are between songs, and the display will be
			# over-written as soon as this is done, so we have to sleep to make sure
			# the message is displayed.
			my $displayTime=3;
			Slim::Display::Animation::showBriefly($client,string('PLUGIN_WEBLOGGER_ERROR_TITLE'),$@,$displayTime);
			print STDERR string('PLUGIN_WEBLOGGER_ERROR_TITLE').": $@\n";
			sleep($displayTime);
		}

		# $paramsRef->[1] will contain the file URL...
		# Example : file:///M:/Aerosmith/Greatest%20Hits/09%20Come%20Together.mp3
	}
}

sub getFunctions
{
	# Export the remote hook functions to the server...
	# (we don't need this crap)
	return({});
}

BEGIN
{
	# Register a callback function so that the server knows we want to hook in...
	Slim::Control::Command::setExecuteCallback(\&commandCallback);
}

END
{
	# Un-register our callback function...
	Slim::Control::Command::clearExecuteCallback(\&commandCallback);
}
